import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CSVFile {
	private File file;
	private String name;
	private String columnNames = "";
	
	public CSVFile(File file) {
		super();
		this.file = file;
		this.name = file.getName();
	}
	
	public String getColumnNames() {
		return columnNames;
	}
	
	public void setColumnNames() {
		Scanner myReader;
		try {
			myReader = new Scanner(file);
			while (myReader.hasNextLine()) {
		        String data = myReader.nextLine();
		        columnNames = data;
		        break;
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void writeToConsole() {
		Scanner myReader;
		try {
			myReader = new Scanner(file);
			while (myReader.hasNextLine()) {
		        String line = myReader.nextLine();
		        if(line.equals(columnNames)) {
		        	continue;
		        }else {
		        	System.out.println(line.trim()+", \""+this.name+"\"");
		        }
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
	}
}
