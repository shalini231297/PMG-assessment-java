import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class CSVCombiner {
	
	private static List<CSVFile> files = new ArrayList<>(); 
	
	public static void main(String[] args) {
		for(int i=0;i<args.length;i++) {
			files.add(new CSVFile(new File(args[i])));
		}
		
		for(CSVFile file : files) {
			file.setColumnNames();
		}
		
		String nameOfColumns = null;
		try {
			nameOfColumns = files.get(0).getColumnNames();
			for(CSVFile file: files) {
				if(!nameOfColumns.equals(file.getColumnNames())){
					throw new Exception("Columns are not matching among the files.");
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		System.out.println(nameOfColumns.trim() + ",\"filename\"");
		
		for(CSVFile file: files) {
			file.writeToConsole();
		}
		
	}
}
