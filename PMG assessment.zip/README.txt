1. Open the directory in the command prompt.
2. Run "javac CSVCombiner.java"
3. Run "java CSVCombiner accessories.csv clothing.csv > output.csv"

Ouput will be saved in the output.csv file.